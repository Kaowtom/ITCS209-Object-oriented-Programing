
public class TreeCalculator {

		
	public static int findMax(Node root)
	{	//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	
	public static int findMin(Node root)
	{	//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	//************* BONUS ****************//
	public static double sumTree(Node root)
	{	
		//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
	public static double avgTree(Node root)
	{
		//****YOUR CODE HERE**
		return -1;
		//*********************
	}
	
}
