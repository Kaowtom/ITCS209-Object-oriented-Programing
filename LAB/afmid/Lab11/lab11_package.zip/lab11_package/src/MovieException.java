
//**************************** DO NOT MODIFY THIS CLASS **********************************//

public class MovieException extends Exception {

	public MovieException(String error) {
		super(error);
	}
	
}

//*****************************************************************************//

