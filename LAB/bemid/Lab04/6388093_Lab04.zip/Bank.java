import java.util.ArrayList;
import java.util.List;

public class Bank {
	//1.variable
	private ArrayList<BankAccount> accounts;
	//2.constructor
	public Bank(){
		accounts = new ArrayList<BankAccount>();
	}
	//3.methods
	//add an account to this bank
	public void addAccount(BankAccount a){
		accounts.add(a);
	}
	//gets the sum of the balances of all accounts in this bank
	public double getTotalBalance(){
		
		//**************** YOUR CODE HERE****************
		double TotalBalance=0;
		for(int i=0; i<accounts.size(); i++) {
			BankAccount Bal = accounts.get(i);
			TotalBalance += Bal.getBalance();
		}
		return TotalBalance;
		//*********************************************
	}
	//counts the number of bank account whose balance is at least given value.
	public int countBalanceAtLeast(double atLeast){
		
		//**************** YOUR CODE HERE****************
		int check=0;
		for(int i=0; i<accounts.size(); i++) {
			BankAccount Bal = accounts.get(i);
			if(Bal.getBalance()>=atLeast) {
				check++;
			}
		}
		return check;
		//*********************************************
	}
	
	//finds a bank account with a given number
	public BankAccount find(int accountNumber){
		
		//**************** YOUR CODE HERE****************
		for(int i=0; i<accounts.size(); i++) {
			BankAccount Bal = accounts.get(i);
			if(accountNumber == Bal.getAccountNumber()) {
				return accounts.get(i);
			}
		}
		return null;
		//*********************************************
	}
	
	//gets the bank account with the largest balance.
	public BankAccount getMax(){
		
		//**************** YOUR CODE HERE****************
		double lastmax =0;
		int accnum=0;
		if(accounts.size() == 0) {
			return null;
		}
		for(int i=0; i<accounts.size(); i++) {
			BankAccount Bal = accounts.get(i);
			if(Bal.getBalance()>lastmax) {
				lastmax = Bal.getBalance();
				accnum = i;
			}
		}return accounts.get(accnum);
		//*********************************************
	}
	
	//gets the bank account with the minimum balance.
	public BankAccount getMin(){
		
		//**************** YOUR CODE HERE****************
		double lastmin = 1e9;
		int accnum = 0;
		if(accounts.size() == 0) {
			return null;
		}else {
			for(int i=0; i<accounts.size(); i++) {
				BankAccount num = accounts.get(i);
				if(num.getBalance()<lastmin) {
					lastmin = num.getBalance();
					accnum = i;
				}
			}
		}
		return accounts.get(accnum);
		//*********************************************
	}
	
	
	//finds duplicate accounts by checking the account numbers in O(N) without using Set and Map
	//return the list of all the accounts that are later found to be duplicate, if there is no duplicate simply return an empty list
	public List<BankAccount> findDuplicate(){
//		
//		//**************** YOUR CODE HERE****************
//		List<BankAccount> number = new ArrayList<BankAccount>();
//		int check = 0;
//		for(int i=0; i<accounts.size(); i++) {
//			BankAccount num1 = accounts.get(i);
//			for(int l=i+1; l<accounts.size(); l++) {
//				BankAccount num2 = accounts.get(l);
//				if((num1.getAccountNumber() == num2.getAccountNumber())) {
//					number.add(num2);
//					check++;
//					break;
//				}
//			}
//
//		}
		
		
		
//		int l=0;
//		for(int i=0; i<accounts.size();i++) {
//			l=i+1;
//			BankAccount num1 = accounts.get(i);
//			BankAccount num2 = accounts.get(l);
////			String acc1 = String.valueOf(num1.getAccountNumber());
////			System.out.print(i+" "+acc1);
////			String acc2 = String.valueOf(num2.getAccountNumber());
////			System.out.println(l+" "+acc2);
////			System.out.println(acc1.equals(acc2));
////			if(acc1.equals(acc2)) {
////				number.add(num1);
////				check++;
////				l--;
////			}
//			if(num1.getAccountNumber() == num2.getAccountNumber()) {
//				number.add(num2);
//				check++;
//				l++;
//			}
//		}
		
		
		
//		int i=0;
//		int l=0;
//		int h=0;
//		l=l+i+1;
//		while(1!=0) {
//			BankAccount num1 = accounts.get(i);
//			BankAccount num2 = accounts.get(l);
//			if(num1.getAccountNumber() == num2.getAccountNumber()) {
//				number.add(num2);
//				check++;
//				l++;
//				i=l+1;
//				h++;
//			}else {
//				i++;
//				check++;
//				System.out.print(i+" "+ num1.getAccountNumber()+"  ");
//				System.out.println(l+" "+ num2.getAccountNumber());
//			}
//			if(check == accounts.size()) {
//				if(h==0) {
//					return null;
//				}else {
//					return number;
//				}
//			}
//		}
		
		
		
//		if(check!=0) {
//			return number;
//		}else {
//				return null;
//		}
		return null;
		//*********************************************
	}
	
}
