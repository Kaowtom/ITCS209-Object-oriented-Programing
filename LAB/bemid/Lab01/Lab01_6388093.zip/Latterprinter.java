
public class Latterprinter {
	public static void main(String[] args) {
		System.out.println("x   x");
		System.out.println("xx  x");
		System.out.println("x x x");
		System.out.println("x  xx");
		System.out.println("x   x");
	}
}
