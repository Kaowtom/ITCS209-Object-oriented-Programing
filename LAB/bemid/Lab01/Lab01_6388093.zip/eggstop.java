
public class eggstop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		up();
		down();
		up();
		down();
		last();
		up();
		line();
		down();
		last();
	}
	static void up() {
		System.out.println("  ______");
		System.out.println(" /      \\");
		System.out.println("/        \\");
	}
	static void down() {
		System.out.println("\\        /");
		System.out.println(" \\______/");
	}
	static void last() {
		System.out.println("+--------+");
	}
	static void line() {
		System.out.println("|  stop  |");
	}
}
