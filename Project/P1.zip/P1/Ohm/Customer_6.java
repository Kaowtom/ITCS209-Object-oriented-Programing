//Name: Supakitt Surojanakul
//ID: 6388065
//Section: 3

import java.util.ArrayList;
import java.util.List;

public class Customer {

	// *********************** DO NOT MODIFY ****************************//
	public static enum CustomerType {
		DEFAULT, STUDENT, PROFESSOR, ATHLETE, ICTSTUDENT
	}; // Different types of customers

	private static int customerRunningNumber = 1; // static variable for assigning a unique ID to a customer
	private CanteenICT canteen = null; // reference to the CanteenICT object
	private int customerID = -1; // this customer's ID
	protected CustomerType customerType = CustomerType.DEFAULT; // the type of this customer, initialized with a DEFAULT
																// customer.
	protected List<FoodStall.Menu> requiredDishes = new ArrayList<FoodStall.Menu>(); // List of required dishes
	// *****************************************************************//
	int time_taken = -1;
	FoodStall CurrentFoodStall;
	Table CurrentSeat;

	Customer(CanteenICT _canteen) {
		// ******************* YOUR CODE HERE **********************
		this.canteen = _canteen;
		// Taken time to eat all the require food //
		time_taken = 0;
		if (this.customerType == Customer.CustomerType.DEFAULT) {
			for (int i = 0; i < 5; i++) {
				time_taken = time_taken + FoodStall.EAT_TIME[i];
			}
		}

		else if (this.customerType == Customer.CustomerType.STUDENT) {
			time_taken = FoodStall.EAT_TIME[FoodStall.Menu.DESSERT.ordinal()] * 5;
		}

		else if (this.customerType == Customer.CustomerType.PROFESSOR) {
			time_taken = FoodStall.EAT_TIME[FoodStall.Menu.NOODLES.ordinal()]
					+ FoodStall.EAT_TIME[FoodStall.Menu.BEVERAGE.ordinal()];
		}

		else if (this.customerType == Customer.CustomerType.ATHLETE) {
			time_taken = FoodStall.EAT_TIME[FoodStall.Menu.MEAT.ordinal()] * 3
					+ FoodStall.EAT_TIME[FoodStall.Menu.SALAD.ordinal()]
					+ FoodStall.EAT_TIME[FoodStall.Menu.BEVERAGE.ordinal()];
		}

		// *****************************************************
	}

	public void takeAction() {
		// ************************** YOUR CODE HERE **********************//
		// Sent Customer to the waiting to order queue //
		FoodStall min = this.canteen.foodStalls_Searching().get(0);

		if (!this.canteen.waitToEnterQueue_Searching().isEmpty()
				&& this.canteen.waitToEnterQueue_Searching().get(0) == this && CanteenICT.AvailableToAdd == true) {
			List<FoodStall> tempFoodStalls = this.canteen.foodStalls_Searching();

			do {
				for (FoodStall index : tempFoodStalls) {
					if (min.customerQueue_Clone.size() > index.customerQueue_Clone.size()) {
						min = index;
					}
				}
				if (!min.getMenu().containsAll(this.requiredDishes)) {
					tempFoodStalls.remove(min);
					min = this.canteen.foodStalls_Searching().get(0);
					continue;
				}

			} while (!min.getMenu().containsAll(this.requiredDishes));

			if (min.customerQueue_Clone.size() == 5) {
				return;
			}

			if (min.getMenu().containsAll(this.requiredDishes)) {
				this.canteen.waitToEnterQueue_Searching().remove(0);
				min.getCustomerQueue().add(this);
				CurrentFoodStall = min;
				CanteenICT.AvailableToAdd = false;
			}
		}

		// Ordering and sent to waiting to seat queue //
		else if (CurrentFoodStall != null) {
			if (!CurrentFoodStall.customerQueue_Clone.isEmpty()
					&& CurrentFoodStall.customerQueue_Clone.get(0) == this) {
				if (requiredDishes.size() == 0) {
					if (CurrentFoodStall.customerQueue_Clone.get(0).getCustomerType() == CustomerType.DEFAULT) {
						requiredDishes.add(FoodStall.Menu.NOODLES);
						requiredDishes.add(FoodStall.Menu.DESSERT);
						requiredDishes.add(FoodStall.Menu.MEAT);
						requiredDishes.add(FoodStall.Menu.SALAD);
						requiredDishes.add(FoodStall.Menu.BEVERAGE);

					} else if (CurrentFoodStall.customerQueue_Clone.get(0).getCustomerType() == CustomerType.STUDENT) {
						requiredDishes.add(FoodStall.Menu.DESSERT);
					}

					else if (CurrentFoodStall.customerQueue_Clone.get(0).getCustomerType() == CustomerType.PROFESSOR) {
						requiredDishes.add(FoodStall.Menu.NOODLES);
						requiredDishes.add(FoodStall.Menu.BEVERAGE);
					}

					else if (CurrentFoodStall.customerQueue_Clone.get(0).getCustomerType() == CustomerType.ATHLETE) {
						requiredDishes.add(FoodStall.Menu.MEAT);
						requiredDishes.add(FoodStall.Menu.SALAD);
						requiredDishes.add(FoodStall.Menu.BEVERAGE);
					}
				}

				if (CurrentFoodStall.isWaitingForOrder() == true && CurrentFoodStall.NextCustomerTurn == true) {
					CurrentFoodStall.takeOrder(this.requiredDishes);
					return;
				} else if (CurrentFoodStall.isReadyToServe() == true) {
					CurrentFoodStall.serve();
					this.canteen.waitToSeatQueue_Searching().add(this);
					CurrentFoodStall.getCustomerQueue().remove(this);
					CurrentFoodStall.NextCustomerTurn = false;
					return;
				}
			}
		}
		// Sent to the available Table. //
		if (this.canteen.waitToSeatQueue_Clone.size() != 0) {
			if (this.canteen.waitToSeatQueue_Clone.get(0) == this) {
				for (Table Number : this.canteen.tables_Searching()) {
					if (Number.seatedCustomers_Clone.size() != Table.MAX_SEATS) {
						Number.getSeatedCustomers().add(this);
						CurrentSeat = Number;
						this.canteen.waitToSeatQueue_Searching().remove(this);
						return;
					}
				}
			}
		}
		if (CurrentSeat != null) {
			if (CurrentSeat.seatedCustomers_Clone.contains(this) && time_taken != 0) {
				time_taken--;
				return;
			} else if (time_taken == 0) {
				time_taken = -1;
				canteen.DoneQueue().add(this);
				CurrentSeat.getSeatedCustomers().remove(this);
			}
		}
		// **************************************************************//

	}

	// ***************For hashing, equality checking, and general purposes. DO NOT
	// MODIFY **************************//

	public CustomerType getCustomerType() {
		return this.customerType;
	}

	public int getCustomerID() {
		return this.customerID;
	}

	public void setCustomerID(int CurrentID) {
		this.customerID = CurrentID;
	}

	public int getcustomerRunningNumber() {
		return customerRunningNumber;
	}

	public void nextcustomerRunningNumber() {
		customerRunningNumber++;
	}

	public void running_time_taken() {
		this.time_taken--;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + customerID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (customerID != other.customerID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerType=" + customerType + "]";
	}

	public String getCode() {
		return this.customerType.toString().charAt(0) + "" + this.customerID;
	}

	/**
	 * print something out if VERBOSE is true
	 * 
	 * @param str
	 */
	public void jot(String str) {
		if (CanteenICT.VERBOSE)
			System.out.println(str);

		if (CanteenICT.WRITELOG)
			CanteenICT.append(str, canteen.name + "_state.log");
	}

	// *************************************************************************************************//

}
